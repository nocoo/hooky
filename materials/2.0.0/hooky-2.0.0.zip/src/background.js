import { executeWebhook } from "./webhook.js";
import { handleQuickSend } from "./quicksend.js";
import { buildContextMenus, handleContextMenuClick } from "./contextmenu.js";

const STORE_KEY = "hooky";

// Handle webhook execution requests from popup
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "EXECUTE_WEBHOOK") {
    const { config, context } = message;

    executeWebhook(config, context, message.resolved === true).then((result) => {
      sendResponse(result);
    });

    // Return true to indicate async response
    return true;
  }
});

// Build context menus on startup
chrome.storage.local.get(STORE_KEY).then((data) => {
  const store = data[STORE_KEY];
  buildContextMenus(store?.templates || []);
});

// React to config changes (e.g. user adds/removes templates)
chrome.storage.onChanged.addListener((changes) => {
  if (changes[STORE_KEY]?.newValue) {
    const store = changes[STORE_KEY].newValue;
    buildContextMenus(store.templates || []);
  }
});

// Handle icon click — always dispatch via handleQuickSend
chrome.action.onClicked.addListener((tab) => {
  handleQuickSend(tab);
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  handleContextMenuClick(info, tab);
});
